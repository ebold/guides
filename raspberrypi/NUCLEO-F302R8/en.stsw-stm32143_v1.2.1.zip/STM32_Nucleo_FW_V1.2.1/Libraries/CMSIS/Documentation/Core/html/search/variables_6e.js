var searchData=
[
  ['n',['N',['../union_a_p_s_r___type.html#a7e7bbba9b00b0bb3283dc07f1abe37e0',1,'APSR_Type::N()'],['../unionx_p_s_r___type.html#a2db9a52f6d42809627d1a7a607c5dbc5',1,'xPSR_Type::N()']]],
  ['npriv',['nPRIV',['../union_c_o_n_t_r_o_l___type.html#a35c1732cf153b7b5c4bd321cf1de9605',1,'CONTROL_Type']]]
];
