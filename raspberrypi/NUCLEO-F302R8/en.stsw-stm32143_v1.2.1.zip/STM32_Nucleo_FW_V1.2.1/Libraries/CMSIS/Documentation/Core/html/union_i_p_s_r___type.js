var union_i_p_s_r___type =
[
    [ "_reserved0", "union_i_p_s_r___type.html#ad2eb0a06de4f03f58874a727716aa9aa", null ],
    [ "b", "union_i_p_s_r___type.html#add0d6497bd50c25569ea22b48a03ec50", null ],
    [ "ISR", "union_i_p_s_r___type.html#ab46e5f1b2f4d17cfb9aca4fffcbb2fa5", null ],
    [ "w", "union_i_p_s_r___type.html#a4adca999d3a0bc1ae682d73ea7cfa879", null ]
];